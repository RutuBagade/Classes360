package com.classes360.service;

import org.hibernate.Session;

import com.classes360.beans.Courses;
import com.classes360.repository.CoursesRepo;
import com.classes360.utils.HibernateUtils;

public class CoursesServices implements CoursesRepo {

	public void saveCourse(int courseId, String coursesName, String courseDuration, String courseTrainer,
			String courseFees) {
		Session session = HibernateUtils.getSessionFactory().openSession();
		session.beginTransaction();
		Courses courses = new Courses(courseId, coursesName, courseDuration, courseTrainer, courseFees);
		session.save(courses);
		session.getTransaction().commit();
	}

}
