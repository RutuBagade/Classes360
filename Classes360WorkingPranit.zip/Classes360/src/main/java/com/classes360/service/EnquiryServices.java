package com.classes360.service;


import org.hibernate.Session;

import com.classes360.beans.Enquiry;
import com.classes360.repository.EnquiryRepo;
import com.classes360.utils.HibernateUtils;

public class EnquiryServices implements EnquiryRepo {

	public void saveEnquiry(String name, String email, String mno) {
		Session session =HibernateUtils.getSessionFactory().openSession();
		session.beginTransaction();
		Enquiry	enquiry = new Enquiry(name, email, mno);
		session.save(enquiry);
		session.getTransaction().commit();
	}
}
