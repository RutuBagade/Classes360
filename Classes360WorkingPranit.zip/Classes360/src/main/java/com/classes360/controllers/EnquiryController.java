package com.classes360.controllers;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;


import com.classes360.beans.Enquiry;
import com.classes360.service.EnquiryServices;
import com.classes360.utils.HibernateUtils;

@WebServlet(value = "/Enquiry")
public class EnquiryController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		EnquiryServices es = new EnquiryServices();
		es.saveEnquiry(request.getParameter("name"), request.getParameter("email"), request.getParameter("mno"));
		RequestDispatcher rd=request.getRequestDispatcher("enquiry.jsp");
		rd.forward(request, response);
		
	}

}
