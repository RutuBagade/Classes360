package com.classes360.controllers;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

import com.classes360.beans.Courses;
import com.classes360.service.CoursesServices;


@WebServlet(value = "/Course")
public class CoursesController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		System.out.println("Course Controller Called from UI");

		CoursesServices cs = new CoursesServices();
		cs.saveCourse(11, request.getParameter("coursesName"), 
						  request.getParameter("courseDuration"), 
						  request.getParameter("courseTrainer"), 
						  request.getParameter("courseFees"));
		
		
		
		RequestDispatcher rd=request.getRequestDispatcher("adminCourses.jsp");
		rd.forward(request, response);
	}

}