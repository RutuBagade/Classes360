package com.classes360.repository;

import com.classes360.beans.Enquiry;

public interface EnquiryRepo {

	public void saveEnquiry(String name, String email, String mno);

}
