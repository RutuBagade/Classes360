package com.classes360.repository;

public interface CoursesRepo {
	
	public void saveCourse(int courseId , String coursesName, String courseDuration, String courseTrainer, String courseFees);
}
