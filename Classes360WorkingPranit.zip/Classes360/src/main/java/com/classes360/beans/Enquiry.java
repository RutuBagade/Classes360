package com.classes360.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Enquiry")
public class Enquiry {

	@Id
	@Column
	private String name;
	@Column
	private String email;
	@Column
	private String mno;

	public Enquiry() {
		// TODO Auto-generated constructor stub
	}

	public Enquiry(String name, String email, String mno) {
		super();
		this.name = name;
		this.email = email;
		this.mno = mno;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMno() {
		return mno;
	}

	public void setMno(String mno) {
		this.mno = mno;
	}

	@Override
	public String toString() {
		return "Enquiry [name=" + name + ", email=" + email + ", mno=" + mno + "]";
	}

	
	
}
